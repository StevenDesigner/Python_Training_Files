<style>
	.msg-box{
		display: block;
		position: fixed;
		top:20%;
		right:40%;
		z-index: 1000px;
		background-color:rgba(7, 177, 112, 0.89) ;
		padding:10px;
		border-radius: 5px;
		width:25%;
		border:10px solid rgba(0, 0, 0, 0.68);
	}
	.back-box{
		display: block;
		position: fixed;
		top: 0px;
		left:100px;
		height: 100%;
		width: 100%;
		z-index: 999px;
		background-color: rgba(0, 0, 0, 0.80);
	}
</style>
<div class="back-box">
<div class="msg-box">

	<center><h4 id="msg"><i class="fa fa-fw fa-check"></i>  Data Succesfully Added.</h4></center>
</div>
</div>