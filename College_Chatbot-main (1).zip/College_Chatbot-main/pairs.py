pairs = [
    [
        r"hi|hey|hello|hiiiiiiiiiii",
        ["hello","hi"]
    ],
    [
        r"What is your name ?",
        ["My name is chatbot created to talk to people "]
    ],
    [
        r"How are you ?",
        ["I am fine...thankyou\n What about you??"]
    ],
    [
        r"(.*) college name ?",
        ["PMU"]
    ],
    [
        r"(.*) college time ?",
        ["9:00am to 4:00pm"]
    ],
    [
        r"how is weather in (.*)",
        ["Weather is awesome in %1.....you will love it"]
    ],
    [
        r"(.*) bye| bye (.*)|quit|bye",
        ["Okay bye it wasn't nice talking to you","bye bye take care"]
    ],
    [
        r"I am (.*)",
        ['You are welcome %1']
    ]
]